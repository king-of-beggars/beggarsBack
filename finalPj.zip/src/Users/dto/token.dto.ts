export class TokenDto {
    public userName : string;
    public userNickname : string;
    public userId : number;
}

export default TokenDto;