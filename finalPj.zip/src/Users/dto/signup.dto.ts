export class SignupDto {
    public userName : string;
    public userNickname : string;
    public userPwd : string;
}

export default SignupDto;