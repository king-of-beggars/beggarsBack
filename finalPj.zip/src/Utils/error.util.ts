export class ErrorUtil extends Error {
    
}